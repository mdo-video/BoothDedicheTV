(function () {
  var PORT = 8080, PHOTO_MS = 6000, REFRESH_MS = 30000;
  var $ = function (id) { return document.getElementById(id); };
  var base = "", items = [], cards = [], slide = null, timer = null, cur = 0;

  function show(id) { ["setup", "gallery"].forEach(function (s) { $(s).classList.toggle("hidden", s !== id); }); }
  function url(kind, name) { return base + "/" + kind + "/" + encodeURIComponent(name); }
  function thumb(n) { return n.replace(/\.[^.]+$/, "") + ".jpg"; }
  function isPhoto(n) { return /\.jpg$/i.test(n); }
  function ev(n) { var i = n.lastIndexOf("_"); return i > 0 ? n.slice(0, i) : ""; }
  function when(t) { var d = new Date(t); return t ? d.toLocaleString("it-IT", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : ""; }

  function connect(host) {
    host = host.trim();
    if (!host) { $("msg").textContent = "Scrivi l'indirizzo IP."; return; }
    base = "http://" + (host.indexOf(":") > -1 ? host : host + ":" + PORT);
    $("msg").textContent = "Mi collego…";
    load(function (ok) {
      if (ok) { localStorage.setItem("host", host); show("gallery"); focusFirst(); }
      else $("msg").textContent = "Il telefono camera non risponde. Controlla IP e Wi-Fi.";
    });
  }

  function load(done) {
    var x = new XMLHttpRequest();
    x.open("GET", base + "/list"); x.timeout = 6000;
    x.onload = function () {
      try {
        items = JSON.parse(x.responseText).sort(function (a, b) { return b.time - a.time; });
        render(); done && done(true);
      } catch (e) { done && done(false); }
    };
    x.onerror = x.ontimeout = function () { done && done(false); };
    x.send();
  }

  function render() {
    var keep = document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.name : null;
    var g = $("grid"); g.innerHTML = ""; cards = [];
    $("count").textContent = items.length ? "· " + items.length : "";
    $("empty").classList.toggle("hidden", items.length > 0);
    var groups = {}, order = [];
    items.forEach(function (it) { var e = ev(it.name); if (!groups[e]) { groups[e] = []; order.push(e); } groups[e].push(it); });
    order.forEach(function (e) {
      if (e && order.length > 1) { var h = document.createElement("div"); h.className = "ev"; h.textContent = e + " · " + groups[e].length; g.appendChild(h); }
      var row = document.createElement("div"); row.className = "row"; g.appendChild(row);
      groups[e].forEach(function (it) {
        var c = document.createElement("div"); c.className = "card f"; c.tabIndex = 0; c.dataset.name = it.name;
        c.innerHTML = '<img src="' + url("t", thumb(it.name)) + '" alt=""><div class="t">' + when(it.time) + '</div>' + (isPhoto(it.name) ? "" : '<div class="k">Video</div>');
        c.onclick = function () { open(it); };
        row.appendChild(c); cards.push(c);
      });
    });
    if (keep) cards.some(function (c) { if (c.dataset.name === keep) { c.focus(); return true; } });
  }

  function open(it) {
    var v = $("vid"), p = $("pic");
    cur = Math.max(0, items.indexOf(it));
    $("viewer").classList.remove("hidden");
    $("cap").textContent = when(it.time);
    clearTimeout(timer);
    if (isPhoto(it.name)) {
      v.pause(); v.style.display = "none"; p.style.display = "block"; p.src = url("h", it.name);
      if (slide !== null) timer = setTimeout(next, PHOTO_MS);
    } else {
      p.style.display = "none"; v.style.display = "block"; v.src = url("h", it.name);
      v.onended = function () { if (slide !== null) next(); else close(); };
      v.onerror = function () { if (slide !== null) next(); };
      v.play();
    }
  }
  function next() { if (slide === null || !items.length) return; slide = (slide + 1) % items.length; open(items[slide]); }
  function close() {
    clearTimeout(timer); slide = null;
    var v = $("vid"); v.pause(); v.removeAttribute("src"); v.load();
    $("viewer").classList.add("hidden");
    var c = document.querySelector(".card:focus") || cards[0]; c && c.focus();
  }
  function startShow() { if (!items.length) return; slide = 0; open(items[0]); }

  // navigazione col telecomando (frecce = sposta il focus, OK = apri, Indietro = chiudi)
  function focusables() { return [].slice.call(document.querySelectorAll(".screen:not(.hidden) .f")); }
  function focusFirst() { var f = focusables(); f.length && f[0].focus(); }
  function move(dir) {
    var cur = document.activeElement, list = focusables();
    if (!cur || list.indexOf(cur) < 0) { focusFirst(); return; }
    var a = cur.getBoundingClientRect(), best = null, bd = 1e9;
    list.forEach(function (el) {
      if (el === cur) return;
      var b = el.getBoundingClientRect(), dx = (b.left + b.width / 2) - (a.left + a.width / 2), dy = (b.top + b.height / 2) - (a.top + a.height / 2);
      var ok = dir === "L" ? dx < -5 : dir === "R" ? dx > 5 : dir === "U" ? dy < -5 : dy > 5;
      if (!ok) return;
      var d = (dir === "L" || dir === "R") ? Math.abs(dx) + 4 * Math.abs(dy) : Math.abs(dy) + 4 * Math.abs(dx);
      if (d < bd) { bd = d; best = el; }
    });
    if (best) { best.focus(); best.scrollIntoView({ block: "center" }); }
  }

  document.addEventListener("keydown", function (e) {
    var k = e.keyCode, typing = document.activeElement && document.activeElement.tagName === "INPUT";
    var viewer = !$("viewer").classList.contains("hidden");
    if (k === 461 || k === 27 || (k === 8 && !typing)) { e.preventDefault(); if (viewer) close(); else if (!$("gallery").classList.contains("hidden")) show("setup"); return; }
    if (viewer) {
      if ((k === 39 || k === 37) && items.length) { e.preventDefault(); cur = (cur + (k === 39 ? 1 : items.length - 1)) % items.length; if (slide !== null) slide = cur; open(items[cur]); }
      if (k === 13 || k === 415 || k === 19) { var v = $("vid"); if (v.style.display !== "none") { v.paused ? v.play() : v.pause(); } }
      return;
    }
    var map = { 37: "L", 38: "U", 39: "R", 40: "D" };
    if (map[k] && !(typing && (k === 37 || k === 39))) { e.preventDefault(); move(map[k]); }
    else if (k === 13 && document.activeElement && document.activeElement.tagName !== "INPUT") document.activeElement.click();
  });

  $("connect").onclick = function () { connect($("host").value); };
  $("host").addEventListener("keydown", function (e) { if (e.keyCode === 13) connect(this.value); });
  $("play").onclick = startShow;
  $("refresh").onclick = function () { load(); };
  $("change").onclick = function () { show("setup"); $("host").focus(); };
  setInterval(function () { if (!$("gallery").classList.contains("hidden") && $("viewer").classList.contains("hidden")) load(); }, REFRESH_MS);

  var saved = localStorage.getItem("host");
  if (saved) { $("host").value = saved; connect(saved); } else $("host").focus();
})();
